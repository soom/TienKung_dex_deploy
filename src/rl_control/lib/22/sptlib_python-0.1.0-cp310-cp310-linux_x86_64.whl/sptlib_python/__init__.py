"""
SPT Library Python Bindings - 预编译版本
此包包含预编译的C++扩展，无需编译环境即可安装使用
"""
# 导入模块中的所有公共符号
from . import sptlib_python  # 这是.so文件的模块名
from .sptlib_python import *

__all__ = ['funcSPTrans']

# 版本信息
__version__ = "0.1.0"
